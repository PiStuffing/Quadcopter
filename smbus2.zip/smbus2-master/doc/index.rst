smbus2
======
.. image:: https://travis-ci.org/kplindegaard/smbus2.svg?branch=master
   :target: https://travis-ci.org/kplindegaard/smbus2

.. image:: https://img.shields.io/pypi/pyversions/smbus2.svg
    :target: https://pypi.python.org/pypi/smbus2

.. image:: https://img.shields.io/pypi/v/smbus2.svg
   :target: https://pypi.python.org/pypi/smbus2

.. automodule:: smbus2
    :members: SMBus, SMBusWrapper, i2c_msg
    :undoc-members:

